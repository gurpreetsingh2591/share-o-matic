package com.medirydes.nemt.retrofit


import com.medirydes.nemt.uiControler.dashboard.model.DefaultModel
import com.medirydes.nemt.uiControler.login.model.company.CompanyModel
import com.medirydes.nemt.uiControler.login.model.loginNew.LoginModelNew
import retrofit2.Call
import retrofit2.http.*


interface ApiInterfaceLogin {
    // login api
    @FormUrlEncoded
    @POST(WebUrl.API_LOGIN)
    fun getLogin(
        @Field(Constant.EMAIL) email: String,
        @Field(Constant.PASSWORD) password: String,
        @Field(Constant.COMPANY_ID) company_id: String
    ): Call<LoginModelNew>

    @FormUrlEncoded
    @POST(WebUrl.API_BIO_LOGIN)
    fun getLoginWithBio(
        @Field(Constant.COMPANY_ID) company_id: String,
        @Field(Constant.DEVICE_ID) DEVICE_ID: String
    ): Call<LoginModelNew>

    @FormUrlEncoded
    @POST(WebUrl.API_VERIFY_COMPANY)
    fun getCompanyVerify(
        @Field(Constant.COMPANY_CODE) email: String,
    ): Call<CompanyModel>
    @FormUrlEncoded

    @POST(WebUrl.API_FORGOT_PASSWORD)
    fun getForgotPassword(
        @Field(Constant.EMAIL) email: String,
    ): Call<DefaultModel>
    }