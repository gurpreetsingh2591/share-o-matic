package com.shareomatic.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.medirydes.nemt.uiControler.dashboard.model.schedule_new.Trip;
import com.google.gson.Gson;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class TripStatusSharedPreference {

    public static final String PREFS_NAME = "PRODUCT_APP";
    public static final String CART = "Product_Cart";


    public TripStatusSharedPreference() {
        super();
    }

    // This four methods are used for maintaining favorites.
    public void saveStatus(Context context, List<Trip> favorites) {
        SharedPreferences settings;
        SharedPreferences.Editor editor;

        settings = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        editor = settings.edit();

        Gson gson = new Gson();
        String jsonFavorites = gson.toJson(favorites);

        editor.putString(CART, jsonFavorites);

        editor.apply();
    }

    public void addStatus(Context context, Trip product) {
        List<Trip> favorites = getStatus(context);
        if (favorites == null)
            favorites = new ArrayList<>();
        favorites.add(product);
        saveStatus(context, favorites);
    }

    public void removeStatus(Context context, int pos) {
        ArrayList<Trip> favorites = getStatus(context);
        if (favorites != null) {
            favorites.remove(pos);
            saveStatus(context, favorites);
        }
    }


    public void ClearStatus(Context context) {
        ArrayList<Trip> favorites = getStatus(context);
        if (favorites != null) {
            favorites.clear();
            saveStatus(context, favorites);
        }
    }

    public void UpdateStatus(Context context, Trip itemModel, int pos) {
        ArrayList<Trip> favorites = getStatus(context);
        if (favorites != null) {
            //favorites.get(pos).setStatus(itemModel.getStatus());
            saveStatus(context, favorites);
        }
    }

    public ArrayList<Trip> getStatus(Context context) {
        SharedPreferences settings;
        List<Trip> favorites=new ArrayList<Trip>();

        settings = context.getSharedPreferences(PREFS_NAME,
                Context.MODE_PRIVATE);

        if (settings.contains(CART)) {
            String jsonFavorites = settings.getString(CART, null);
            Gson gson = new Gson();
            Trip[] favoriteItems = gson.fromJson(jsonFavorites,
                    Trip[].class);

            favorites = Arrays.asList(favoriteItems);
            favorites = new ArrayList<Trip>(favorites);
        } else
            return (ArrayList<Trip>) favorites;

        return (ArrayList<Trip>) favorites;
    }



}
