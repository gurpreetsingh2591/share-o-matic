package com.shareomatic.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.medirydes.nemt.uiControler.dashboard.model.admin.AddLegModel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class LegsSharedPreference {

    public static final String PREFS_NAME = "medirydes_admin";
    public static final String LEGS = "trip_legs";


    public LegsSharedPreference() {
        super();
    }

    // This four methods are used for maintaining favorites.
    public void saveLegs(Context context, List<AddLegModel> favorites) {
        SharedPreferences settings;
        SharedPreferences.Editor editor;

        settings = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        editor = settings.edit();

        Gson gson = new Gson();
        String jsonFavorites = gson.toJson(favorites);

        editor.putString(LEGS, jsonFavorites);

        editor.apply();
    }

    public void addLegs(Context context, AddLegModel product) {
        List<AddLegModel> favorites = getLegs(context);
        if (favorites == null)
            favorites = new ArrayList<>();
        favorites.add(product);
        saveLegs(context, favorites);
    }

    public void removeLegs(Context context, int pos) {
        ArrayList<AddLegModel> favorites = getLegs(context);
        if (favorites != null) {
            favorites.remove(pos);
            saveLegs(context, favorites);
        }
    }


    public void ClearLegs(Context context) {
        ArrayList<AddLegModel> favorites = getLegs(context);
        if (favorites != null) {
            favorites.clear();
            saveLegs(context, favorites);
        }
    }

    public void UpdateLegs(Context context, AddLegModel itemModel, int pos) {
        ArrayList<AddLegModel> favorites = getLegs(context);
        if (favorites != null) {
            favorites.set(pos,itemModel);
            saveLegs(context, favorites);
        }
    }

    public void UpdateTripNumber(Context context, AddLegModel itemModel, int pos) {
        ArrayList<AddLegModel> favorites = getLegs(context);
        if (favorites != null) {

            saveLegs(context, favorites);
        }
    }


    public ArrayList<AddLegModel> getLegs(Context context) {
        SharedPreferences settings;
        List<AddLegModel> favorites=new ArrayList<>();

        settings = context.getSharedPreferences(PREFS_NAME,
                Context.MODE_PRIVATE);

        if (settings.contains(LEGS)) {
            String jsonFavorites = settings.getString(LEGS, null);
            Gson gson = new Gson();
            AddLegModel[] favoriteItems = gson.fromJson(jsonFavorites,
                    AddLegModel[].class);

            favorites = Arrays.asList(favoriteItems);
            favorites = new ArrayList<AddLegModel>(favorites);
        } else
            return (ArrayList<AddLegModel>) favorites;

        return (ArrayList<AddLegModel>) favorites;
    }



}
