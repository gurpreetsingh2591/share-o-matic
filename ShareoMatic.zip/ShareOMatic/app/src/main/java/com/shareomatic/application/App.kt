package com.medirydes.nemt.application

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import com.medirydes.nemt.utils.SharedPrefrencesUtils

class App : Application() {
    private var currentApplication: App? = null

    override fun onCreate() {
        super.onCreate()
        currentApplication = this
        SharedPrefrencesUtils.init(applicationContext)
        SharedPrefrencesUtils.initCompany(applicationContext)
        SharedPrefrencesUtils.initBioAuth(applicationContext)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        //  val appComponent = DaggerApplicationComponent.create()

    }

    fun getInstance(): App? {

        return currentApplication
    }


}