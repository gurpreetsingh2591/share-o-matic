package com.medirydes.nemt.utils

import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.graphics.Paint
import android.location.Location
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.provider.Settings
import android.text.TextUtils
import android.util.Log
import android.util.Patterns
import android.view.*
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.EditText
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.messaging.FirebaseMessaging
import com.medirydes.nemt.R
import com.medirydes.nemt.annotation.Constants
import com.medirydes.nemt.interfaces.DialogClickListener
import com.medirydes.nemt.interfaces.MapSelectionListener
import com.medirydes.nemt.interfaces.ReminderPopUpListener
import kotlinx.android.synthetic.main.dialog_map_selection.*
import java.text.DateFormat
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*


class Static {
    var alertDialog: AlertDialog? = null
    lateinit var dialogClickListener: DialogInterface

    fun statusBarColor(activity: Activity, color: Int) {
        val window: Window = activity.window
        val decor = window.decorView
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            decor.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        }
        window.statusBarColor = color;
    }

    fun toggleFullscreen(fullscreen: Boolean, activity: Activity) {
        val attrs = activity.window.attributes
        if (fullscreen) {
            attrs.flags = attrs.flags or WindowManager.LayoutParams.FLAG_FULLSCREEN
        } else {
            attrs.flags = attrs.flags and WindowManager.LayoutParams.FLAG_FULLSCREEN.inv()
        }
        activity.window.attributes = attrs
    }


    fun isValidEmail(target: CharSequence?): Boolean {
        return !TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches()
    }

    fun showDialog(activity: Activity, title: String) {
        AlertDialog.Builder(activity)
            .setTitle(title)
            .setCancelable(false)
            .setPositiveButton(
                Constants.OK
            ) { dialog, _ ->
                // do something...
                dialog.dismiss()
            }
            .show()
    }

    fun rotate_Clockwise(view: View?) {
        val rotate = ObjectAnimator.ofFloat(view, "rotation", 180f, 0f)
        //        rotate.setRepeatCount(10);
        rotate.duration = 500
        rotate.start()
    }

    fun rotate_AntiClockwise(view: View?) {
        val rotate = ObjectAnimator.ofFloat(view, "rotation", 0f, 180f)
        //        rotate.setRepeatCount(10);
        rotate.duration = 500
        rotate.start()
    }

    fun TextView.showStrikeThrough(show: Boolean) {
        paintFlags =
            if (show) paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            else paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
    }

    fun getDeviceId(activity: Activity): String {
        return Settings.Secure.getString(
            activity.contentResolver, Settings.Secure.ANDROID_ID
        )
    }

    fun status(status: String): String {
        var tripStatus = ""
        if (status == Constants.not_started) {
            tripStatus = "Not Started"
            return tripStatus
        } else if (status == Constants.ended_with_sign) {
            tripStatus = "Completed"
            return tripStatus
        } else if (status == Constants.no_show) {
            tripStatus = "No-show"
            return tripStatus
        } else if (status == Constants.cancelled_with_sign) {
            tripStatus = "Canceled"
            return tripStatus
        } else if (status == Constants.manually_cancelled) {
            tripStatus = "Manually Canceled"
            return tripStatus
        } else if (status == Constants.manually_completed) {
            tripStatus = "Manually Completed"
            return tripStatus
        } else {
            tripStatus = "Started"
            return tripStatus
        }

        return tripStatus
    }

    private var progressDialog: Dialog? = null


    fun cancelLoading() {
        if (progressDialog != null && progressDialog!!.isShowing) progressDialog!!.cancel()
    }

    fun convertKmsToMiles(kms: Float): Float {
        return (kms / 1.609).toFloat()
    }

    fun convertIntoMiles(km: Double): Double {

        val ans = Math.round(km / 1.609);
        return ans.toDouble()
    }

    @Throws(ParseException::class)
    fun timeCoversion24to12(twelveHoursTime: String?): String? {

        //Date/time pattern of input date (12 Hours format - hh used for 12 hours)
        val df: DateFormat = SimpleDateFormat("HH:mm")

        //Date/time pattern of desired output date (24 Hours format HH - Used for 24 hours)
        val outputformat: DateFormat = SimpleDateFormat("hh:mm aa")
        var date: Date? = null
        var output: String? = null

        //Returns Date object
        date = df.parse(twelveHoursTime)

        //old date format to new date format
        output = outputformat.format(date)
        println(output)
        return output
    }


    @Throws(ParseException::class)
    fun timeCoversion12to24(twelveHoursTime: String?): String? {

        //Date/time pattern of input date (12 Hours format - hh used for 12 hours)
        val df: DateFormat = SimpleDateFormat("hh:mm")

        //Date/time pattern of desired output date (24 Hours format HH - Used for 24 hours)
        val outputformat: DateFormat = SimpleDateFormat("HH:mm")
        var date: Date? = null
        var output: String? = null

        //Returns Date object
        date = df.parse(twelveHoursTime)

        //old date format to new date format
        output = outputformat.format(date)
        println(output)
        return output
    }


    fun convertIntoKms(miles: Double): Double {
        val ans = Math.round(1.609 * miles);
        return ans.toDouble()
    }


    fun fadeIn(view: View, activity: Activity) {
        val animMoveToTop =
            AnimationUtils.loadAnimation(activity, com.medirydes.nemt.R.anim.fadein);
        view.startAnimation(animMoveToTop)

        animMoveToTop.setAnimationListener(object : Animation.AnimationListener {
            override fun onAnimationRepeat(animation: Animation?) {

            }

            override fun onAnimationEnd(animation: Animation?) {
                view.visibility = View.VISIBLE

            }

            override fun onAnimationStart(animation: Animation?) {
            }

        })
    }


    fun slideToTop(activity: Activity, view: View, animation: Int) {
        val animMoveToTop = AnimationUtils.loadAnimation(activity, animation);
        view.startAnimation(animMoveToTop)

        animMoveToTop.setAnimationListener(object : Animation.AnimationListener {
            override fun onAnimationRepeat(animation: Animation?) {

            }

            override fun onAnimationEnd(animation: Animation?) {
                view.visibility = View.VISIBLE

            }

            override fun onAnimationStart(animation: Animation?) {
            }

        })
    }

    fun getCurrentDate(): String {
        val locale: Locale = Locale.getDefault()
        val sdf = SimpleDateFormat(Constants.DATE_FORMAT, locale)
        return sdf.format(Date())
    }

    @SuppressLint("SimpleDateFormat")
    fun getDateFormat(date: String, format: String): String {

        val formatIn = SimpleDateFormat(Constants.DATE_FORMAT_IN)
        val formatOut = SimpleDateFormat(format)
        val calendar = Calendar.getInstance()
        calendar.time = formatIn.parse(date)

        return formatOut.format(calendar.time)

    }

    fun getCDate(date: String): String {
        val locale: Locale = Locale.getDefault()
        val sdf = SimpleDateFormat(Constants.DATE_FORMAT_IN, locale)
        val formatOut = SimpleDateFormat(Constants.DATE_FORMAT, locale)
        val calendar = Calendar.getInstance()
        calendar.time = sdf.parse(date)
        return formatOut.format(calendar.time)
    }

    fun getDynamicFormatDate(date: String, format: String): String {
        var formatType = ""
        if (format == "m-d-Y") {
            formatType = "MM-dd-yyyy"
        }
        if (format == "d-m-Y") {
            formatType = "dd-MM-yyyy"
        }
        if (format == "Y-m-d") {
            formatType = "yyyy-MM-dd"
        }
        if (format == "yyyy-MM-dd") {
            formatType = "MM-dd-yyyy"
        }
        val locale: Locale = Locale.getDefault()
        val sdf = SimpleDateFormat(Constants.DATE_FORMAT_IN, locale)
        val formatOut = SimpleDateFormat(formatType, locale)
        val calendar = Calendar.getInstance()
        calendar.time = sdf.parse(date)
        return formatOut.format(calendar.time)
    }

    fun getText(data: Any): String {
        var str = ""
        if (data is EditText) {
            str = data.text.toString()
        } else if (data is String) {
            str = data
        }
        return str
    }

    fun isValidMobile(data: Any, updateUI: Boolean = true): Boolean {
        val str = getText(data)
        var valid = true
        if (str.isEmpty()) {
            valid = false
            if (updateUI) {
                val error: String? =
                    Validator.activity?.getString(com.medirydes.nemt.R.string.phone_required_msg)
                Validator.setError(data, error)
            }
        } else {
            valid = str.trim().length > 10

            // Set error if required
            if (updateUI) {
                val error: String? =
                    if (valid) null else Validator.activity?.getString(com.medirydes.nemt.R.string.full_phone_required_msg)
                Validator.setError(data, error)
            }
        }

        return valid
    }

    fun dialog(
        activity: Activity,
        msg: String,
        toastMsg: String,
        dialogClickListener: DialogClickListener
    ) {
        val builder = AlertDialog.Builder(activity)
        builder.setMessage(msg)
        builder.setPositiveButton(Constants.YES) { dialog, _ ->

            dialogClickListener.onClickYes(Constants.YES)
            dialog.dismiss()
            //  Toast.makeText(activity, toastMsg, Toast.LENGTH_LONG).show()
        }
        builder.setNegativeButton(Constants.NO) { dialog, _ ->
            dialog.dismiss()
            dialogClickListener.onClickNo(Constants.NO)

        }
        val alertDialog: AlertDialog = builder.create()
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    fun checkList(selected: ArrayList<String?>) {
        val selectedlist: ArrayList<String?> = selected
    }

    fun getSpeed(currentLocation: Location, oldLocation: Location): Double {
        val newLat: Double = currentLocation.latitude
        val newLon: Double = currentLocation.longitude
        val oldLat: Double = oldLocation.latitude
        val oldLon: Double = oldLocation.longitude
        if (currentLocation.hasSpeed()) {
            return currentLocation.speed.toDouble()
        } else {
            val radius = 6371000.0
            val dLat = Math.toRadians(newLat - oldLat)
            val dLon = Math.toRadians(newLon - oldLon)
            val a = sin(dLat / 2) * sin(dLat / 2) +
                    cos(Math.toRadians(newLat)) * cos(Math.toRadians(oldLat)) *
                    sin(dLon / 2) * sin(dLon / 2)
            val c = 2 * asin(sqrt(a))
            val distance = Math.round(radius * c).toDouble()
            val timeDifferent: Long = currentLocation.time - oldLocation.time
            return distance / timeDifferent
        }
    }

    fun mapSelectionDialog(activity: Activity?, mapSelectionListener: MapSelectionListener) {
        val dialog = Dialog(activity!!)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window!!.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.dialog_map_selection)
        val window: Window? = dialog.window
        val wlp = window!!.attributes
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        wlp.windowAnimations = R.style.DialogAnimation
        wlp.gravity = Gravity.BOTTOM
        wlp.y = 100
        window.attributes = wlp

        dialog.llGoogleMap.setOnClickListener {
            mapSelectionListener.googleMap()
            dialog.dismiss()
        }
        dialog.llWaze.setOnClickListener {
            mapSelectionListener.waze()
            dialog.dismiss()
        }
        dialog.llCancel.setOnClickListener {
            mapSelectionListener.cancel()
            dialog.dismiss()
        }
        dialog.show()
    }

    fun reminderPopUp(context: Context, reminderPopUpListener: ReminderPopUpListener) {
        val builder1 = AlertDialog.Builder(context)
        builder1.setMessage("Would like to put Member On Board.")
        builder1.setCancelable(true)

        builder1.setPositiveButton(
            "Yes"
        ) { dialog, id ->

            reminderPopUpListener.yes()
            dialog.cancel()
        }

        builder1.setNegativeButton(
            "No"
        ) { dialog, id ->
            reminderPopUpListener.no()
            dialog.cancel()
        }

        val alert11 = builder1.create()
        alert11.show()
    }

    fun distance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val theta = lon1 - lon2
        var dist = (sin(deg2rad(lat1))
                * sin(deg2rad(lat2))
                + (cos(deg2rad(lat1))
                * cos(deg2rad(lat2))
                * cos(deg2rad(theta))))
        dist = acos(dist)
        dist = rad2deg(dist)
        dist *= 60 * 1.1515
        return dist
    }

    private fun deg2rad(deg: Double): Double {
        return deg * Math.PI / 180.0
    }

    private fun rad2deg(rad: Double): Double {
        return rad * 180.0 / Math.PI
    }

    fun capitalizeString(str: String): String {
        var retStr = str
        try { // We can face index out of bound exception if the string is null
            retStr = str.substring(0, 1).toUpperCase() + str.substring(1)
        } catch (e: Exception) {
        }
        return retStr
    }


    @SuppressLint("SimpleDateFormat")
    fun dateFormatString(date: String): String {
        val parser = SimpleDateFormat("yyyy-MM-dd")
        val formatter = SimpleDateFormat("MM/dd")

//        val format = DateTimeFormatter.ofPattern("yyyy-MM-dd")
//        val localDate: LocalDate = LocalDate.parse(str, format)
//        val formatter = DateTimeFormatter.ofPattern("dd/MM", Locale.getDefault())

        return formatter.format(parser.parse(date)!!)
    }

    @SuppressLint("SimpleDateFormat")
    fun dateFormat2String(date: String): String {
        val parser = SimpleDateFormat("yyyy-MM-dd")
        val formatter = SimpleDateFormat("MMM dd yyyy")

        return formatter.format(parser.parse(date)!!)
    }

    @SuppressLint("SimpleDateFormat")
    fun dateFormat2mmddyy(date: String): String {
        val parser = SimpleDateFormat("yyyy-MM-dd")
        val formatter = SimpleDateFormat("MM/dd/yyyy")

        return formatter.format(parser.parse(date)!!)
    }


    @SuppressLint("SimpleDateFormat")
    fun dateFormatChange(date: String): String {
        val parser = SimpleDateFormat("yyyy-MM-dd hh:mm:ss")
        val formatter = SimpleDateFormat("MMM dd yyyy  hh:mm")
        return formatter.format(parser.parse(date)!!)
    }


    @SuppressLint("SimpleDateFormat")
    @RequiresApi(Build.VERSION_CODES.O)
    fun timeCalculationString(startTime: String, endTime: String): String {
        val simpleDateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")

        val date1 = simpleDateFormat.parse(startTime)
        val date2 = simpleDateFormat.parse(endTime)

        val difference: Long = date2.time - date1.time
        val strDiff: String = difference.toString()

        if (strDiff.contains("-")) {
            return "00H 00M 00S"
        } else {
            val days = (difference / (1000 * 60 * 60 * 24)).toInt()
            var hours = ((difference - 1000 * 60 * 60 * 24 * days) / (1000 * 60 * 60)).toInt()
            val min =
                (difference - 1000 * 60 * 60 * 24 * days - 1000 * 60 * 60 * hours).toInt() / (1000 * 60)
            hours = if (hours < 0) -hours else hours
            Log.i("======= Hours", " :: $hours")
            return "" + hours + "H  " + min + "M  " + "00S"
        }
    }

    fun Any?.ifNullOrEmpty(default: String) =
        if (this == null || (this is CharSequence && this.isEmpty()))
            default
        else
            this.toString()

    @RequiresApi(Build.VERSION_CODES.M)
    fun isOnline(context: Context): Boolean {
        val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        if (connectivityManager != null) {
            val capabilities =
                connectivityManager.getNetworkCapabilities(connectivityManager.activeNetwork)

            if (capabilities != null) {
                if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                    Log.i("Internet", "NetworkCapabilities.TRANSPORT_CELLULAR")
                    return true
                } else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                    Log.i("Internet", "NetworkCapabilities.TRANSPORT_WIFI")
                    return true
                } else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
                    Log.i("Internet", "NetworkCapabilities.TRANSPORT_ETHERNET")
                    return true
                }
            }
        }
        return false
    }

    fun onTokenRefresh() {
        FirebaseMessaging.getInstance().token.addOnCompleteListener(OnCompleteListener { task ->
            if (!task.isSuccessful) {
                Log.w(Constants.TAG, "Fetching FCM registration token failed", task.exception)
                return@OnCompleteListener
            }

            // Get new FCM registration token
            val token = task.result

            // Log and toast
            //    val msg = getString("msg_token_fmt", token)
            Log.e("Token ---- ", token)
            SharedPrefrencesUtils.setFcmToken(token)
            //  Toast.makeText(baseContext, token, Toast.LENGTH_SHORT).show()
        })
    }

    fun createDialog(msg: String, activity: Activity) {
        val alertDialogBuilder = AlertDialog.Builder(activity)
        alertDialogBuilder.setTitle(activity.getString(com.medirydes.nemt.R.string.app_name))
        alertDialogBuilder.setMessage(msg)
        alertDialogBuilder.setPositiveButton("OK") { _: DialogInterface, _: Int ->
            alertDialog!!.dismiss()
        }
        alertDialogBuilder.setCancelable(false)
        alertDialog = alertDialogBuilder.create()
        alertDialog!!.show()
    }

}

