package com.medirydes.nemt.interfaces

interface DialogClickListener {
    fun onClickYes(yes:String)
    fun onClickNo(no:String)
}