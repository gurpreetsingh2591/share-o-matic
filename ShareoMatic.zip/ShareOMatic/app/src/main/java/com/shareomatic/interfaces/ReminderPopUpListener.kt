package com.medirydes.nemt.interfaces

interface ReminderPopUpListener {
    fun yes()
    fun no()
}