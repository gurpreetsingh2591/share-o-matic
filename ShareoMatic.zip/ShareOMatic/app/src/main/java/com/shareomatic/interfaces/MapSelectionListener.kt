package com.medirydes.nemt.interfaces

interface MapSelectionListener {
    fun googleMap()
    fun waze()
    fun cancel()
}