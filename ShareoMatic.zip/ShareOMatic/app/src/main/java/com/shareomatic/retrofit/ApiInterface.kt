package com.medirydes.nemt.retrofit


import com.google.gson.JsonArray
import com.medirydes.nemt.uiControler.dashboard.model.DefaultModel
import com.medirydes.nemt.uiControler.dashboard.model.admin.broker_model.BrokerModel
import com.medirydes.nemt.uiControler.dashboard.model.admin.company_trips.CompanyTripModel
import com.medirydes.nemt.uiControler.dashboard.model.admin.driver_list.DriverListModel
import com.medirydes.nemt.uiControler.dashboard.model.admin.driver_report.DriverReportModel
import com.medirydes.nemt.uiControler.dashboard.model.admin.leg_detail.LegDetailModel
import com.medirydes.nemt.uiControler.dashboard.model.admin.legs_model.LegsListModel
import com.medirydes.nemt.uiControler.dashboard.model.admin.passenger_model.PassengerListModel
import com.medirydes.nemt.uiControler.dashboard.model.admin.trip_number.TripNumberModel
import com.medirydes.nemt.uiControler.dashboard.model.admin.vehicle_list_model.VehicleListModel
import com.medirydes.nemt.uiControler.dashboard.model.avalibilty.AvailabilityModel
import com.medirydes.nemt.uiControler.dashboard.model.driver_vehicle_list.DriverVehicleModel
import com.medirydes.nemt.uiControler.dashboard.model.exchange_trip.ExchangeTripModel
import com.medirydes.nemt.uiControler.dashboard.model.notification_model.NotificationModel
import com.medirydes.nemt.uiControler.dashboard.model.profile.ProfileModel
import com.medirydes.nemt.uiControler.dashboard.model.scheduleStatus.ScheduleStatusModel
import com.medirydes.nemt.uiControler.dashboard.model.schedule_new.ScheduleModel
import com.medirydes.nemt.uiControler.dashboard.model.total_trips.TotalTripsModl
import com.medirydes.nemt.uiControler.dashboard.model.tripStatus.TripStatusModel
import com.medirydes.nemt.uiControler.dashboard.model.tripsLog.TripsLogModel
import com.medirydes.nemt.uiControler.login.model.company.CompanyModel
import com.medirydes.nemt.uiControler.login.model.loginNew.LoginModelNew
import com.medirydes.nemt.uiControler.tripDetail.model.tripDetail.TripDetailModel
import okhttp3.MultipartBody
import okhttp3.RequestBody
import org.json.JSONArray
import retrofit2.Call
import retrofit2.http.*


interface ApiInterface {

    /*Driver API's*/

    // login api
    @FormUrlEncoded
    @POST(WebUrl.API_LOGIN)
    fun getLogin(
        @Field(Constant.EMAIL) email: String,
        @Field(Constant.PASSWORD) password: String,
        @Field(Constant.COMPANY_ID) company_id: String
    ): Call<LoginModelNew>

    @FormUrlEncoded
    @POST(WebUrl.API_VERIFY_COMPANY)
    fun getCompanyVerify(
        @Field(Constant.COMPANY_CODE) email: String,
    ): Call<CompanyModel>

    @FormUrlEncoded
    @POST(WebUrl.API_FORGOT_PASSWORD)
    fun getForgotPassword(
        @Field(Constant.EMAIL) email: String,
    ): Call<DefaultModel>

    // get dashboard data
    @GET(WebUrl.API_GET_DASHBOARD)
    fun getDashboardData(
    ): Call<ScheduleModel>

    // get future data
    @GET(WebUrl.API_GET_FUTURE)
    fun getFutureData(
    ): Call<ScheduleModel>

    // get future data
    @GET(WebUrl.API_GET_REPORTS)
    fun getReportData(
        @Query(Constant.FROM_DATE) fromDate: String,
        @Query(Constant.TO_DATE) toDate: String,
    ): Call<ScheduleModel>


    //get start Schedule
    @FormUrlEncoded
    @POST(WebUrl.API_START_SCHEDULE+"/{id}")
    fun getStartSchedule(
        @Path("id") id: String?,
        @Field(Constant.METHOD) method: String,
        @Field(Constant.STATUS) status: String
    ): Call<ScheduleStatusModel>

    // get change status
    @GET(WebUrl.API_GET_CHANGE_STATUS)
    fun getChangeStatus(
    ): Call<DefaultModel>

    //post Edit Profile
    @Multipart
    @POST(WebUrl.API_GET_EDIT_PROFILE)
    fun getEditProfile(
        @PartMap partMap: HashMap<String, RequestBody>,
        @Part file: MultipartBody.Part
    ): Call<ProfileModel>


    // get future data
    @GET(WebUrl.API_GET_PROFILE_DATA)
    fun getProfileData(
    ): Call<ProfileModel>


    @Multipart
    @POST(WebUrl.API_GET_EDIT_PROFILE)
    fun getEditProfileWithoutImage(
        @PartMap partMap: HashMap<String, RequestBody>,
    ): Call<ProfileModel>


    //get send inspection list
    @FormUrlEncoded
    @POST(WebUrl.API_GET_INSPECTION_DETAIL)
    fun getSendInspectionList(
        @Field(Constant.SCHEDULE_ID) schedule_id: String,
        @Field(Constant.VEHICLE_ID) vehicle_id: String,
        @Field(Constant.CHECKUPS) checkups: JSONArray,
        @Field(Constant.SHIFT) shift: String
    ): Call<DefaultModel>

    //get send inspection list
    @FormUrlEncoded
    @POST(WebUrl.API_POST_REARRANGE_LIST)
    fun getSendReArrangeList(
        @Field("ids[]") list:ArrayList<String>
    ): Call<ScheduleModel>

    //get send inspection list
    @FormUrlEncoded
    @POST(WebUrl.API_POST_REARRANGE_LIST)
    fun getSendReArrangeListFuture(
        @Field("ids[]") list:ArrayList<String>
    ): Call<ScheduleModel>

    // get Inspection Json Data
    @GET(WebUrl.JSON_GET_INSPECTION_LIST)
    fun getInspectionJsonData(
    ): Call<JsonArray>

    // get Availability Data
    @GET(WebUrl.API_GET_AVAILABILITY)
    fun getAvailabilityData(
    ): Call<AvailabilityModel>


    //get start Trip
    @FormUrlEncoded
    @POST(WebUrl.API_GET_START_TRIP+"/{id}")
    fun getStartTrip(
        @Path("id") id: String?,
        @Field(Constant.METHOD) method: String,
        @Field(Constant.STATUS) status: String,
        @Field(Constant.Cancellation_Reason) cancellation_reason: String,
        @Field(Constant.Drop_Off_Status) drop_off_status: String,
        @Field("lat") lat: Double,
        @Field("lng") lng: Double,
        @Field("cancel_no_show_note") cancel_no_show_note: String
    ): Call<TripStatusModel>



    //get  Trip

    @GET(WebUrl.API_GET_START_TRIP+"/{id}")
    fun getTrip(
        @Path("id") id: String?
    ): Call<TripStatusModel>

    //get start Schedule
    @FormUrlEncoded
    @POST(WebUrl.API_POST_AVAILABILITY)
    fun getEditAvailability(
        @Field("work_days") status: String,
    ): Call<DefaultModel>


    //get send incident images
    @Multipart
    @POST(WebUrl.API_POST_INCIDENT)
    fun getIncidentImages(
        @Part file: ArrayList<MultipartBody.Part?>,
        @Part("description") description:RequestBody
    ): Call<DefaultModel>



    //get send token
    @FormUrlEncoded
    @POST(WebUrl.API_POST_TOKEN)
    fun getSendToken(
        @Field(Constant.TOKEN) token: String,
    ): Call<DefaultModel>


    //get notification
    @GET(WebUrl.API_GET_NOTIFICATIONS)
    fun getNotification(
        @Query(Constant.PAGE) page: Int,
    ): Call<NotificationModel>


    //get trip Logs
    @GET(WebUrl.API_GET_START_TRIP)
    fun getLogTrip(
        @Query(Constant.PAGE) page: Int,
    ): Call<TripsLogModel>


    @FormUrlEncoded
    @POST(WebUrl.API_GET_PDF_LOG)
    fun getLogPdf(
        @Field("trip_id") trip_id: String,
    ): Call<TripsLogModel>

    //get trip Detail
    @GET(WebUrl.API_GET_START_TRIP+"/{id}")
    fun getTripDetail(
        @Path("id") id: String?,
    ): Call<TripDetailModel>


    @Multipart
    @POST(WebUrl.API_TRIP_SIGNATURE)
    fun getCompleteTrip(
        @Part("leg_id") trip_id: RequestBody,
        @Part driverSignFile: MultipartBody.Part,
        @Part PassengerSignFile: MultipartBody.Part,
        @Part("status") status: RequestBody,
    ): Call<DefaultModel>

    //save driver signature
    @Multipart
    @POST(WebUrl.API_DRIVER_ADD_SIGNATURE)
    fun getSaveDriverSign(
        @Part driverSignFile: MultipartBody.Part,
    ): Call<DefaultModel>

    @Multipart
    @POST(WebUrl.API_TRIP_SIGNATURE)
    fun getCompleteTripWithoutPassenger(
        @Part("leg_id") trip_id: RequestBody,
        @Part driverSignFile: MultipartBody.Part,
        @Part("status") status: RequestBody,
    ): Call<DefaultModel>

    @Multipart
    @POST(WebUrl.API_TRIP_SIGNATURE)
    fun getCompleteTripWithoutDriverSignature(
        @Part("leg_id") trip_id: RequestBody,
        @Part passengerSignFile: MultipartBody.Part,
        @Part("status") status: RequestBody,
    ): Call<DefaultModel>

    @Multipart
    @POST(WebUrl.API_TRIP_SIGNATURE)
    fun getCancelTripWithoutSignature(
        @Part("leg_id") trip_id: RequestBody,
        @Part("status") status: RequestBody,
    ): Call<DefaultModel>



    @FormUrlEncoded
    @POST(WebUrl.API_DRIVER_VEHICLE)
    fun getDriverVehicle(
        @Field("leg_id") trip_id: String,
    ): Call<DriverVehicleModel>


    @FormUrlEncoded
    @POST(WebUrl.API_EXCHANGE_TRIP)
    fun getExchangeTrip(
        @Field("trip_id") trip_id: String,
        @Field("user_id") user_id: String,
        @Field("vehicle_id") vehicle_id: String,
        @Field("exchange_reason") exchange_reason: String,
        @Field("leg_id") trip_type: String,
    ): Call<ExchangeTripModel>



    @FormUrlEncoded
    @POST(WebUrl.API_REMOVE_AVAILABILITY)
    fun getRemoveEvent(
        @Field("date") date: String,
    ): Call<DefaultModel>

    @FormUrlEncoded
    @POST(WebUrl.API_update_device_id)
    fun getUpdateDeviceId(
        @Field(Constant.DEVICE_ID) device_id: String
    ): Call<DefaultModel>


    /* admin API's*/

    //get broker list
    @GET(WebUrl.API_BROKER_LIST)
    fun getBrokerList(
        @Query("company_id") id: String?,
    ): Call<BrokerModel>

    //get passenger list
    @GET(WebUrl.API_PASSENGER_LIST)
    fun getPassengerList(
        @Query("company_id") id: String?,
    ): Call<PassengerListModel>


    //get passenger list
    @GET(WebUrl.API_COMPANY_TRIP_LIST)
    fun getCompanyTripList(
    ): Call<CompanyTripModel>

    //get passenger list
    @GET(WebUrl.API_COMPANY_TRIP_LEGS_LIST)
    fun getTripLegList(
        @Query("trip_id") id: String?,
    ): Call<LegsListModel>


    //get trip number
    @GET(WebUrl.API_TRIP_NUMBER)
    fun getTripNumber(
    ): Call<TripNumberModel>

    //get vehicle list
    @GET(WebUrl.API_VEHICLE_LIST)
    fun getVehicleList(
        @Query("company_id") id: String?,
    ): Call<VehicleListModel>

    //get trip number
    @GET(WebUrl.API_DRIVER_LIST)
    fun getDriverList(
        @Query("leg_id") id: String?,
    ): Call<DriverListModel>

    @FormUrlEncoded
    @POST(WebUrl.API_CREATE_TRIP)
    fun getCreateTrip(
        @FieldMap  partMap: HashMap<String, String>,
        @Field ("trip_number[]")trip_number: ArrayList<String>,
        @Field ("appointment_time[]")appointment_time: ArrayList<String>,
        @Field ("pickup_time[]")pickup_time: ArrayList<String>,
        @Field ("origin_name[]")origin_name: ArrayList<String>,
        @Field ("origin_street_address[]")origin_street_address: ArrayList<String>,
        @Field ("origin_comments[]")origin_comments: ArrayList<String>,
        @Field ("origin_latitude[]")origin_latitude: ArrayList<String>,
        @Field ("origin_longitude[]")origin_longitude: ArrayList<String>,
        @Field ("destination_name[]")destination_name: ArrayList<String>,
        @Field ("destination_street_address[]")destination_street_address: ArrayList<String>,
        @Field ("destination_comments[]")destination_comments: ArrayList<String>,
        @Field ("destination_longitude[]")destination_longitude: ArrayList<String>,
        @Field ("destination_latitude[]")destination_latitude: ArrayList<String>,
        @Field ("trip_waiting_time[]")trip_waiting_time: ArrayList<String>
    ): Call<DefaultModel>



    @FormUrlEncoded
    @POST(WebUrl.API_CANCEL_TRIP)
    fun getCancelTrip(
        @Field ("leg_id")leg_id: String,
        @Field ("status")status: String,
        @Field ("cancellation_reason")cancellation_reason: String,
    ): Call<DefaultModel>

    @FormUrlEncoded
    @POST(WebUrl.API_ASSIGN_TRIP)
    fun getAssignTrip(
        @Field ("driver")driver:String,
        @Field ("vehicle")vehicle: String,
        @Field ("legs[]")legs: ArrayList<String>,
    ): Call<DefaultModel>

    @FormUrlEncoded
    @POST(WebUrl.API_COMPLETE_TRIP)
    fun getCompleteTrip(
        @Field ("leg_id")leg_id:String,
        @Field ("actual_pickup_time")actual_pickup_time:String,
        @Field ("pickup_time")pickup_time:String,
        @Field ("drop_off_time")drop_off_time:String,
    ): Call<DefaultModel>

    @FormUrlEncoded
    @POST(WebUrl.API_UN_ASSIGN_TRIP)
    fun getUnAssignTrip(
        @Field ("leg_id")leg_id:String
    ): Call<DefaultModel>


    @GET(WebUrl.API_DELETE_TRIP)
    fun getDeleteTrip(
        @Query ("leg_id")leg_id:String,
        @Query ("trip_id")trip_id:String,
    ): Call<DefaultModel>


    //get driver report
    @GET(WebUrl.API_DRIVER_REPORT)
    fun getDriverReport(
        @Query("driver_id") id: String?,
    ): Call<DriverReportModel>

    //get leg list
    @GET(WebUrl.API_DASHBOARD_API)
    fun getDashboardApi(
        @Query("status") status: String?,
    ): Call<LegsListModel>

    //get leg detail
    @GET(WebUrl.API_LEG_DETAIL_API)
    fun getLegDetailApi(
        @Query("legs_id") legs_id: String?,
    ): Call<LegDetailModel>

    @FormUrlEncoded
    @POST(WebUrl.API_LEG_UPDATE_API)
    fun getUpdateLeg(
        @FieldMap  partMap: HashMap<String, String>,
    ): Call<DefaultModel>


    //get send notification
    @GET(WebUrl.API_SEND_NOTIFICATION_API)
    fun getPickUpNotificationApi(
        @Query("driverid") driverId: String?,
        @Query("passengername") passengerName: String?,
        @Query("drivername") driverName: String?,
    ): Call<DefaultModel>

    //get payment status
    @GET(WebUrl.API_PAYMENT_STATUS_API)
    fun getPaymentStatusApi(
        @Query("leg_id") leg_id: String?,
        @Query("payment_status") payment_status: String?,
    ): Call<DefaultModel>

    //get total trips
    @GET(WebUrl.API_TOTAL_TRIP_API)
    fun getTotalTrips(
    ): Call<TotalTripsModl>
    //get total assigned/unassigned
    @GET(WebUrl.API_ASSIGN_API)
    fun getTotalAssignedUnassignedTrips(
    ): Call<TotalTripsModl>
}