package com.medirydes.nemt.utils

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.medirydes.nemt.R
import com.medirydes.nemt.annotation.Constants
import com.medirydes.nemt.retrofit.Constant
import com.pusher.client.channel.PrivateChannel
import org.json.JSONObject

class LocationService : Service() {
    private var mLocationManager: LocationManager? = null
    private lateinit var channel: PrivateChannel
    private val authorizationEndpoint = Constant.BASE_URL + Constant.pusher
    var mLocationListeners = arrayOf(
        LocationListener(LocationManager.GPS_PROVIDER),
        LocationListener(LocationManager.NETWORK_PROVIDER)
    )
    private val NOTIFICATION_CHANNEL_ID = "my_notification_location"

    class LocationListener(provider: String) : android.location.LocationListener {
        internal var mLastLocation: Location

        init {
            Log.e(TAG, "LocationListener $provider")
            mLastLocation = Location(provider)
        }

        override fun onLocationChanged(location: Location) {
            Log.e(TAG, "onLocationChanged: $location")
            mLastLocation.set(location)
            Log.e(
                "LastLocation",
                mLastLocation.latitude.toString() + "  " + mLastLocation.longitude.toString()
            )

            SharedPrefrencesUtils.setCurrentLat(mLastLocation.latitude.toString())
            SharedPrefrencesUtils.setCurrentLong(mLastLocation.longitude.toString())


        }

        override fun onProviderDisabled(provider: String) {
            Log.e(TAG, "onProviderDisabled: $provider")
        }

        override fun onProviderEnabled(provider: String) {

            Log.e(TAG, "onProviderEnabled: $provider")
        }

        override fun onStatusChanged(provider: String, status: Int, extras: Bundle) {
            Log.e(TAG, "onStatusChanged: $provider")
        }

    }

    override fun onBind(arg0: Intent): IBinder? {
        return null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.e(TAG, "onStartCommand")
        super.onStartCommand(intent, flags, startId)
        return Service.START_STICKY

    }

    override fun onCreate() {


        val deleteIntent = Intent(this, LocationReceiver::class.java)
        deleteIntent.apply {
            action = "Delete"
            putExtra("UserId", "100")
            putExtra("notificationId", 1)
        }
        val deletePendingIntent = PendingIntent.getBroadcast(this, 0, deleteIntent, 0)

        val builder: NotificationCompat.Builder =
            NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
                .setOngoing(false)
                .setSmallIcon(R.drawable.app_icon)
                .setContentTitle("Location")
                .setColor(ContextCompat.getColor(applicationContext, R.color.app_base_color))
                .setContentText("If you turn these notifications off, the location you're sharing with others may not be refreshed, and is likely to become inaccurate.")
                .addAction(R.drawable.app_icon, "Stop Sharing location", deletePendingIntent)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager: NotificationManager =
                getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            val notificationChannel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                NOTIFICATION_CHANNEL_ID, NotificationManager.IMPORTANCE_LOW
            )
            notificationChannel.description = NOTIFICATION_CHANNEL_ID
            notificationChannel.setSound(null, null)
            notificationManager.createNotificationChannel(notificationChannel)
            startForeground(1, builder.build())
        }
        Log.e(TAG, "onCreate")
        initializeLocationManager()
        try {
            mLocationManager!!.requestLocationUpdates(
                LocationManager.NETWORK_PROVIDER, LOCATION_INTERVAL.toLong(), LOCATION_DISTANCE,
                mLocationListeners[1]
            )
        } catch (ex: java.lang.SecurityException) {
            Log.e(TAG, "fail to request location update, ignore", ex)
        } catch (ex: IllegalArgumentException) {
            Log.e(TAG, "network provider does not exist, " + ex.message)
        }

        try {
            mLocationManager!!.requestLocationUpdates(
                LocationManager.GPS_PROVIDER, LOCATION_INTERVAL.toLong(), LOCATION_DISTANCE,
                mLocationListeners[0]
            )
        } catch (ex: java.lang.SecurityException) {
            Log.e(TAG, "fail to request location update, ignore", ex)
        } catch (ex: IllegalArgumentException) {
            Log.e(TAG, "gps provider does not exist " + ex.message)
        }
//        callTrigerEvent()
    }

    override fun onDestroy() {
        Log.e(TAG, "onDestroy")
        super.onDestroy()
        if (mLocationManager != null) {
            for (i in mLocationListeners.indices) {
                try {
                    mLocationManager!!.removeUpdates(mLocationListeners[i])
                } catch (ex: Exception) {
                    Log.i(TAG, "fail to remove location listners, ignore", ex)
                }

            }
        }
    }

    private fun initializeLocationManager() {
        Log.e(TAG, "initializeLocationManager")
        if (mLocationManager == null) {
            mLocationManager =
                applicationContext.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        }

    }

    companion object {
        private val TAG = "BOOMBOOMTESTGPS"
        private val LOCATION_INTERVAL = 1000
        private val LOCATION_DISTANCE = 0f
    }


    fun callTrigerEvent() {


        val lat = SharedPrefrencesUtils.getCurrentLat()!!.toDouble()
        val long = SharedPrefrencesUtils.getCurrentLong()!!.toDouble()

        Log.e("lat", lat.toString())
        Log.e("long", long.toString())

        val jsonObject = JSONObject()
        jsonObject.put("lat", lat)
        jsonObject.put("lng", long)
        jsonObject.put("id", SharedPrefrencesUtils.getUserId().toString())
        jsonObject.put("name", SharedPrefrencesUtils.getUserName().toString())
        jsonObject.put("licno", SharedPrefrencesUtils.getLicenceNo().toString())
        channel.trigger(Constants.client_coordinates, jsonObject.toString())


    }


}
